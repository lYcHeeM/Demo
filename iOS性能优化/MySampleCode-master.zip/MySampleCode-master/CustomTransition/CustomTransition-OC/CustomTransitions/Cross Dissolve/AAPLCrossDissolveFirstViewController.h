/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The initial view controller for the Cross Dissolve demo.
 */

@import UIKit;

@interface AAPLCrossDissolveFirstViewController : UIViewController
@end
