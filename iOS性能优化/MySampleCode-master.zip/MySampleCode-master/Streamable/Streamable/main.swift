//
//  main.swift
//  Streamable
//
//  Created by 张星宇 on 16/1/26.
//  Copyright © 2016年 zxy. All rights reserved.
//

import Foundation

testPrintStruct()
testCreateString()

testCustomStringConvertible()
testCustomDebugStringConvertible()