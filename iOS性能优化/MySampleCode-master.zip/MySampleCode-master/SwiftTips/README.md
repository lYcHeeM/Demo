# 几个加速Swift开发的小tip

这份代码是[《几个加速Swift开发的小tip》](http://www.jianshu.com/p/5ebd5e8ecf60)一文的demo,主要介绍了Swift中很不错，但也很容易忽视的小tip，掌握这些小技巧能够一定程度上加快开发速度，写出更好的代码