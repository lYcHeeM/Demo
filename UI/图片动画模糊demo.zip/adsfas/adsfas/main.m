//
//  main.m
//  ANBlurredImageViewDemo
//
//  Created by Aaron Ng on 1/5/14.
//  Copyright (c) 2014 Delve. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ANAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ANAppDelegate class]));
    }
}
