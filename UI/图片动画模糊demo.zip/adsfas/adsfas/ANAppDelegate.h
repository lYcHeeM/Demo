//
//  ANAppDelegate.h
//  ANBlurredImageViewDemo
//
//  Created by Aaron Ng on 1/5/14.
//  Copyright (c) 2014 Delve. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ANAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
